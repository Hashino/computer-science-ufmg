long double fib_rec(long double n);
long double fib_ite(long double n);
long double fac_rec(long double n);
long double fac_ite(long double n);
